# My Module with Australian Weather
This module allows for some basic functionality with Australian Weather data (csv).

## Installation

```bash
pip install setuptools wheel
python setup.py sdist bdist_wheel

pip install my_module
```
